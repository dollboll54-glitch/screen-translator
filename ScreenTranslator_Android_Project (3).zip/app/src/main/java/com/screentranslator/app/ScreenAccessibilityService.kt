package com.screentranslator.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScreenAccessibilityService : AccessibilityService() {

    companion object {
        var instance: ScreenAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // নতুন মেসেজ আসলে ব্যাকগ্রাউন্ডে রেডি থাকা
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    /**
     * ভাসমান আইকন যেখানে ছাড়া হয়েছে (targetX, targetY),
     * স্ক্রিনের ওই নির্দিষ্ট বাউন্ডিং বক্সের ভেতরে থাকা ভিউয়ের টেক্সট উদ্ধার করে।
     */
    fun findTextAtCoordinates(targetX: Int, targetY: Int): String? {
        val rootNode = rootInActiveWindow ?: return null
        return searchNodeRecursively(rootNode, targetX, targetY)
    }

    private fun searchNodeRecursively(node: AccessibilityNodeInfo, targetX: Int, targetY: Int): String? {
        val rect = Rect()
        node.getBoundsInScreen(rect)

        // যদি স্পর্শকৃত পয়েন্টটি এই ভিউটির সীমানার মধ্যে থাকে
        if (rect.contains(targetX, targetY)) {
            // যদি এই নোডটিতে সরাসরি টেক্সট থাকে
            val text = node.text?.toString()
            if (!text.isNullOrBlank()) {
                return text
            }
        }

        // চাইল্ড নোডগুলো পরীক্ষা করা
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = searchNodeRecursively(child, targetX, targetY)
            if (!result.isNullOrBlank()) {
                return result
            }
        }

        return null
    }
}
