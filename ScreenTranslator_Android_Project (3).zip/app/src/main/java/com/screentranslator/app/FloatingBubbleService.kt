package com.screentranslator.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.Vibrator
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private var overlayCardView: View? = null
    private lateinit var params: WindowManager.LayoutParams

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundService()
        initFloatingBubble()
    }

    private fun startForegroundService() {
        val channelId = "screen_translator_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Screen Translator Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Screen Translator সক্রিয়")
            .setContentText("ভাসমান আইকনটি যেকোনো ইংরেজি লেখার উপর টেনে ধরুন")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()

        startForeground(1001, notification)
    }

    private fun initFloatingBubble() {
        val inflater = LayoutInflater.from(this)
        floatingView = inflater.inflate(R.layout.layout_floating_bubble, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
        }

        val bubbleIcon = floatingView?.findViewById<ImageView>(R.id.bubble_icon)

        bubbleIcon?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()

                    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                        isDragging = true
                    }

                    params.x = initialX + deltaX
                    params.y = initialY + deltaY
                    windowManager.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        // আঙুল ছেড়ে দিলে স্ক্রিনের সেই স্থানের টেক্সট রিড করতে পাঠানো
                        triggerHapticFeedback()
                        requestTranslationAt(event.rawX.toInt(), event.rawY.toInt())
                    } else {
                        // শুধু ট্যাপ করলে সেটিংস মেনু বা মিনি ডিকশনারি খোলা
                        toggleMenu()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(floatingView, params)
    }

    private fun triggerHapticFeedback() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        vibrator?.vibrate(40)
    }

    private fun requestTranslationAt(screenX: Int, screenY: Int) {
        val accessibilityService = ScreenAccessibilityService.instance
        if (accessibilityService != null) {
            val textFound = accessibilityService.findTextAtCoordinates(screenX, screenY)
            if (!textFound.isNullOrBlank()) {
                translateAndDisplay(textFound, screenX, screenY)
            } else {
                showToastOverlay("কোনো লেখা পাওয়া যায়নি!")
            }
        } else {
            showToastOverlay("অনুগ্রহ করে অ্যাক্সেসিবিলিটি পারমিশন অন করুন!")
        }
    }

    private fun translateAndDisplay(englishText: String, posX: Int, posY: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            val translatedBengali = TranslationEngine.translateEnToBn(englishText)
            launch(Dispatchers.Main) {
                OverlayResultWindow.show(this@FloatingBubbleService, windowManager, englishText, translatedBengali, posX, posY)
            }
        }
    }

    private fun toggleMenu() {
        // Quick popup options
    }

    private fun showToastOverlay(msg: String) {
        // UI Feedback
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { windowManager.removeView(it) }
        OverlayResultWindow.dismiss()
    }
}
