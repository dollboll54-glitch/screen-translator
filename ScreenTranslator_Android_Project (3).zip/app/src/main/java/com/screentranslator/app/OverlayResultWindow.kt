package com.screentranslator.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

object OverlayResultWindow {

    private var popupView: View? = null
    private var windowManager: WindowManager? = null
    private var tts: TextToSpeech? = null

    fun show(
        context: Context,
        wm: WindowManager,
        originalText: String,
        translatedText: String,
        targetX: Int,
        targetY: Int
    ) {
        dismiss()
        this.windowManager = wm

        val inflater = LayoutInflater.from(context)
        popupView = inflater.inflate(R.layout.layout_translation_overlay_card, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = Math.max(100, targetY - 120) // মেসেজের একটু ওপরে সুন্দরভাবে স্থাপন
        }

        popupView?.findViewById<TextView>(R.id.tv_original_text)?.text = originalText
        popupView?.findViewById<TextView>(R.id.tv_translated_text)?.text = translatedText

        // ক্লোজ বাটন
        popupView?.findViewById<ImageView>(R.id.btn_close_overlay)?.setOnClickListener {
            dismiss()
        }

        // কপি বাটন
        popupView?.findViewById<ImageView>(R.id.btn_copy_translation)?.setOnClickListener {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Bengali Translation", translatedText)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, "অনুবাদ কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
        }

        // স্পিকার / উচ্চারণ বাটন
        popupView?.findViewById<ImageView>(R.id.btn_speak_text)?.setOnClickListener {
            if (tts == null) {
                tts = TextToSpeech(context) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        tts?.language = Locale.ENGLISH
                        tts?.speak(originalText, TextToSpeech.QUEUE_FLUSH, null, "tts_id")
                    }
                }
            } else {
                tts?.speak(originalText, TextToSpeech.QUEUE_FLUSH, null, "tts_id")
            }
        }

        wm.addView(popupView, params)
    }

    fun dismiss() {
        try {
            popupView?.let {
                windowManager?.removeView(it)
                popupView = null
            }
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            // Safe dismiss
        }
    }
}
