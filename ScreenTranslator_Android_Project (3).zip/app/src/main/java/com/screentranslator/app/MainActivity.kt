package com.screentranslator.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnOverlayPermission: Button
    private lateinit var btnAccessibilityPermission: Button
    private lateinit var btnToggleService: Button
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnOverlayPermission = findViewById(R.id.btn_overlay_permission)
        btnAccessibilityPermission = findViewById(R.id.btn_accessibility_permission)
        btnToggleService = findViewById(R.id.btn_toggle_service)
        tvStatus = findViewById(R.id.tv_service_status)

        // ১. ডিসপ্লে ওভার অ্যাপস পারমিশন
        btnOverlayPermission.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "ভাসমান পারমিশন আগেই দেওয়া আছে!", Toast.LENGTH_SHORT).show()
            }
        }

        // ২. অ্যাক্সেসিবিলিটি পারমিশন
        btnAccessibilityPermission.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "তালিকায় 'Screen Translator' খুঁজে On করুন", Toast.LENGTH_LONG).show()
        }

        // ৩. সার্ভিস চালু বা বন্ধ করা
        btnToggleService.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "আগে ভাসমান উইন্ডো পারমিশন চালু করুন", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val serviceIntent = Intent(this, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "ভাসমান বাবল সক্রিয় হয়েছে! যেকোনো লেখার উপর রাখুন।", Toast.LENGTH_LONG).show()
            finish() // অ্যাপ মিনিমাইজ করে দেওয়া
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true

        val hasAccessibility = ScreenAccessibilityService.instance != null

        if (hasOverlay && hasAccessibility) {
            tvStatus.text = "অবস্থা: অ্যাপ প্রস্তুত! 'সার্ভিস চালু করুন' চাপুন।"
            btnToggleService.isEnabled = true
        } else {
            tvStatus.text = "অবস্থা: প্রয়োজনীয় পারমিশনগুলো চালু করুন।"
        }
    }
}
