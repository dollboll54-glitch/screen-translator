package com.screentranslator.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object TranslationEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /**
     * ইংরেজি টেক্সটকে সম্পূর্ণ বিনামূল্যে গুগলের ট্রান্সলেশন এন্ডপয়েন্ট দিয়ে বাংলায় অনুবাদ করে।
     */
    fun translateEnToBn(sourceText: String): String {
        return try {
            val encodedText = URLEncoder.encode(sourceText.trim(), "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=bn&dt=t&q=$encodedText"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return "অনুবাদ ব্যর্থ হয়েছে!"

            val jsonArray = JSONArray(responseBody)
            val sentencesArray = jsonArray.getJSONArray(0)

            val stringBuilder = StringBuilder()
            for (i in 0 until sentencesArray.length()) {
                val sentence = sentencesArray.getJSONArray(i)
                stringBuilder.append(sentence.getString(0))
            }

            stringBuilder.toString()
        } catch (e: Exception) {
            e.printStackTrace()
            "অনুবাদ করতে সমস্যা হয়েছে (ইন্টারনেট কানেকশন চেক করুন)"
        }
    }
}
