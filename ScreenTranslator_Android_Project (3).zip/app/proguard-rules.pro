# Add project specific ProGuard rules here.
-keep class com.screentranslator.app.** { *; }
